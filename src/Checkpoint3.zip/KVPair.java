public class KVPair {
    long key;
    long value;

    public KVPair(long key, long value) {
        this.key = key;
        this.value = value;
    }
}